# Task Ledger

This is the authoritative task status and acceptance ledger. Baseline: HEAD `17b3a60`, audit recorded 2026-09-06. Related existing functionality does not mean its corrective task is complete.

Read [README](README.md), [MASTER_PLAN](MASTER_PLAN.md), and [execution rules](CODEX_EXECUTION_RULES.md) first. Select the first executable unfinished task in numeric order; dependencies are minimum prerequisites, not permission to skip earlier ready P0 work.

## Status index

| ID | Task | Status | Milestone | Priority | Dependencies | Size |
|---|---|---|---|---|---|---|
| [T01](#t01) | Line-ending and test portability | READY | A | P0 | None | S |
| [T02](#t02) | Disposable database integration harness | NOT_STARTED | A | P0 | T01 | M |
| [T03](#t03) | Canonical Constraint Model comparison | NOT_STARTED | A | P0 | T01, T02 | S |
| [T04](#t04) | Canonical candidate intervals | NOT_STARTED | A | P0 | T02, T03 | M |
| [T05](#t05) | Unsupported DWDE policy guard | NOT_STARTED | A | P0 | T01, T03 | M |
| [T06](#t06) | Archive-aware adoption | NOT_STARTED | A | P0 | T02, T04 | M |
| [T07](#t07) | Coherent solver snapshots | NOT_STARTED | A | P0 | T02, T03, T05, T06 | M |
| [T08](#t08) | Candidate stale-schedule binding | NOT_STARTED | A | P0 | T07 | M |
| [T09](#t09) | Session-specific solver locks | NOT_STARTED | A | P0 | T07, T08 | M |
| [T10](#t10) | Manual MOVE through authoritative IR | NOT_STARTED | A | P0 | T03, T04, T05, T06, T07, T08, T09 | M |
| [T11](#t11) | ASSIGN/UNASSIGN canonical authority | NOT_STARTED | A | P0 | T10 | M |
| [T12](#t12) | Rebase/undo canonical authority | NOT_STARTED | A | P0 | T10, T11 | M |
| [T13](#t13) | Close legacy write bypasses | NOT_STARTED | A | P0 | T10, T11, T12 | S |
| [T14](#t14) | Representative full DWDE acceptance fixture/solve | NOT_STARTED | A | P0 | T05, T06, T07, T08, T09, T10, T11, T12, T13 | M |
| [T15](#t15) | Bounded and understandable solve failures | NOT_STARTED | A | P0 | T14 | M |
| [T16](#t16) | Manager workflow/export/mobile verification | NOT_STARTED | A | P0 | T14, T15 | M |
| [T17](#t17) | Preference scoring | NOT_STARTED | C | P1 | T14 | M |
| [T18](#t18) | Soft optimization | NOT_STARTED | C | P1 | T17, T15 | M |
| [T19](#t19) | Candidate comparison/persistence | NOT_STARTED | C | P1 | T18, T08, T16 | M |
| [T20](#t20) | Typed ID targets/parameters | NOT_STARTED | B | P1 | T14 | L |
| [T21](#t21) | Convert DWDE policy into tenant records | NOT_STARTED | B | P1 | T20 | L |
| [T22](#t22) | Tenant-explicit database commands | NOT_STARTED | B | P1 | T02, T13, T16 | L |
| [T23](#t23) | Tenant initialization/selection | NOT_STARTED | C | P1 | T22 | M |
| [T24](#t24) | Remove DWDE operational UI assumptions | NOT_STARTED | C | P1 | T20, T21, T23 | M |
| [T25](#t25) | Generic structured rule authoring | NOT_STARTED | C | P1 | T20, T21, T23 | M |
| [T26](#t26) | CSV intake | NOT_STARTED | C | P1 | T23, T24, T25 | M |
| [T27](#t27) | Studio #2 acceptance | NOT_STARTED | C | P1 | T19, T21, T22, T23, T24, T25, T26 | M |
| [T28](#t28) | AI canonical-context alignment | NOT_STARTED | E | P2 | T25, T22, T27 | M |
| [T29](#t29) | Paid-pilot operations | NOT_STARTED | D/E/F | P2 | T16, T19, T27 | M |

## Verification command contract

Existing commands: `npm run lint`, `npm run typecheck`, `npm test`, `npm run build`; Python: `python -m pytest -q` from solver with its pinned requirements installed in a disposable virtual environment.

Planned commands, not yet implemented: T02 introduces `npm run test:db`; T14 introduces `npm run test:parity`; T16 introduces `npm run test:e2e`. These become stable harness interfaces for dependent tasks. Keep setup/environment instructions in TEST_STRATEGY.md. Never run a placeholder command and report success. No production test targets.

## Execution phases

- Verification: T01–T02.
- Correctness: T03–T10.
- DWDE completion: T11–T16.
- Optimization: T17–T19.
- Generic product: T20–T24.
- Commercial pilot: T25–T29.

L-sized tasks are parent outcomes. Before implementation, record bounded children T20a–c, T21a–b, T22a–c as described below, with their own evidence; parent dependencies and final acceptance remain binding. Do not mark a parent DONE because one child passed.

<a id="t01"></a>

## T01 — Line-ending and test portability

| Field | Value |
|---|---|
| Task ID | T01 |
| Status | READY |
| Milestone | A |
| Priority | P0 |
| Dependencies | None |
| Size | S |
| Risk | Low |
| Reversible? | Yes |

### Objective

Make the existing quality gate reliable on Windows and Linux without weakening ledger integrity.

### Why now

The audit reproduced 15 failures caused by SQL CRLF conversion; normalized isolated SQL passed all 256 tests.

### Expected files/subsystems

- [tests/production-ledger.test.ts](../tests/production-ledger.test.ts)
- [tests/atomic-rulebook-structure-repair.test.ts](../tests/atomic-rulebook-structure-repair.test.ts)
- [tests/fluid-planning-inventory.test.ts](../tests/fluid-planning-inventory.test.ts)
- [tests/rulebook-v36-governance.test.ts](../tests/rulebook-v36-governance.test.ts)
- [tests/schedule-commands-v25.test.ts](../tests/schedule-commands-v25.test.ts)
- [supabase/production-ledger/manifest.json](../supabase/production-ledger/manifest.json)
- [.github/workflows/ci.yml](../.github/workflows/ci.yml)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Windows and Linux checkouts pass all existing TypeScript tests.
- [ ] Canonical ledger byte lengths and hashes remain unchanged; no manifest regeneration to accommodate CRLF.
- [ ] Historical migration SQL semantics and application behavior remain unchanged.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Test clean-checkout line endings and ledger bytes, not only the existing working directory.
- Use repository attributes (new .gitattributes if needed); normalize textual assertions only where byte identity is not the contract.

### Non-goals

Do not change compiler, scheduling, database behavior, package versions, or ledger history.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

No known prerequisite blocker. Inspect current working tree before beginning.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T01 prompt](prompts/T01-line-ending-integrity.md)

<a id="t02"></a>

## T02 — Disposable database integration harness

| Field | Value |
|---|---|
| Task ID | T02 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T01 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Reconstruct and test current database command behavior in a disposable environment.

### Why now

SQL text assertions cannot establish privileges, transaction rollback, migration reconstruction, or RLS behavior.

### Expected files/subsystems

- [supabase/bootstrap/2026-08-31-production-schema-baseline.sql](../supabase/bootstrap/2026-08-31-production-schema-baseline.sql)
- [supabase/production-ledger/README.md](../supabase/production-ledger/README.md)
- [supabase/production-ledger/manifest.json](../supabase/production-ledger/manifest.json)
- [supabase/migrations/README.md](../supabase/migrations/README.md)
- [package.json](../package.json)
- [.github/workflows/ci.yml](../.github/workflows/ci.yml)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] A fresh disposable environment reconstructs the current schema through a documented, dependency-correct sequence.
- [ ] Executed owner/editor/viewer/nonmember tests verify one governed write and stale-version rejection.
- [ ] The harness refuses production targets and exposes npm run test:db, with an actionable setup failure rather than a silent skip.
- [ ] Bootstrap/archive schema differences are resolved in test setup or forward migrations, never by rewriting historical SQL.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Inspect CLI/runtime availability before choosing tooling; use isolated Supabase when auth/vault dependencies require it.
- Document fixture identities, teardown, prerequisites, and migration ledger handling.
- Add a staging recovery procedure outline; no production restore.

### Non-goals

Do not reconcile the production ledger live, provision paid services, or build a general migration framework.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T01. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T02 prompt](prompts/T02-database-integration-harness.md)

<a id="t03"></a>

## T03 — Canonical Constraint Model comparison

| Field | Value |
|---|---|
| Task ID | T03 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T01, T02 |
| Size | S |
| Risk | Medium |
| Reversible? | Yes, preserve historical compatibility |

### Objective

Compare equivalent Constraint Model objects independently of JSON object-key order.

### Why now

A pure diagnostic probe showed equivalent models compare unequal after property reordering.

### Expected files/subsystems

- [lib/constraint-model-version.ts](../lib/constraint-model-version.ts)
- [lib/solver-gateway.ts](../lib/solver-gateway.ts)
- [tests/constraint-model-version.test.ts](../tests/constraint-model-version.test.ts)
- [tests/solver-gateway.test.ts](../tests/solver-gateway.test.ts)
- [supabase/migrations/20260902163046_constraint_model_publication_v30.sql](../supabase/migrations/20260902163046_constraint_model_publication_v30.sql)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Recursively reordered object keys compare equal; meaningful parameter and ordered-array differences compare unequal.
- [ ] A real JSONB publication/read-back compares equal to the submitted semantic model.
- [ ] Historical fingerprint compatibility is documented and tested; no silent historical rehash.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Define object canonicalization explicitly; preserve array ordering unless the contract already declares a set.
- Test nested selectors/parameters and model-sync drift detection.

### Non-goals

Do not weaken drift detection or change scheduling semantics.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T01, T02. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T03 prompt](prompts/T03-constraint-model-canonicalization.md)

<a id="t04"></a>

## T04 — Canonical candidate intervals

| Field | Value |
|---|---|
| Task ID | T04 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T02, T03 |
| Size | M |
| Risk | High |
| Reversible? | Yes |

### Objective

Validate exactly the assignment intervals that adoption will persist.

### Why now

The gateway accepted a 15-minute interval for a 60-minute planning duration; SQL later recomputes the end.

### Expected files/subsystems

- [lib/solver-gateway.ts](../lib/solver-gateway.ts)
- [app/api/solver/adopt/route.ts](../app/api/solver/adopt/route.ts)
- [lib/schedule-command-candidate.ts](../lib/schedule-command-candidate.ts)
- [tests/solver-gateway.test.ts](../tests/solver-gateway.test.ts)
- [supabase/migrations/20260904032500_governed_solver_candidate_adoption.sql](../supabase/migrations/20260904032500_governed_solver_candidate_adoption.sql)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Start/end values and assignment shape are strictly validated; nonfinite, malformed, duplicate, unknown, or cross-midnight assignments are rejected.
- [ ] End times derive from pinned session overrides/class durations before IR evaluation; inconsistent supplied end times fail.
- [ ] Shortened intervals cannot evade teacher availability, sequencing, or overlap checks.
- [ ] Adoption persists the exact validated assignment interpretation and rolls back rejected candidates.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Add a shortened-duration teacher-window regression and a per-session duration override case.
- Keep SQL structural validation as defense in depth; change current function through a forward migration.

### Non-goals

Do not trust browser validation or add an alternative business-rule engine in SQL.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T02, T03. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T04 prompt](prompts/T04-canonical-candidate-intervals.md)

<a id="t05"></a>

## T05 — Unsupported DWDE policy guard

| Field | Value |
|---|---|
| Task ID | T05 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T01, T03 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Prevent changed human policy from silently retaining obsolete static compiler behavior.

### Why now

Changing OPS-003 wording to a 19:00 close still compiled 21:30 in the audit.

### Expected files/subsystems

- [lib/constraint-compiler.ts](../lib/constraint-compiler.ts)
- [lib/constraint-compiler-v3.ts](../lib/constraint-compiler-v3.ts)
- [lib/reviewed-rulebook.ts](../lib/reviewed-rulebook.ts)
- [lib/schedule-readiness.ts](../lib/schedule-readiness.ts)
- [tests/constraint-compiler.test.ts](../tests/constraint-compiler.test.ts)
- [supabase/migrations/20260904190328_rulebook_v36_governed_repairs.sql](../supabase/migrations/20260904190328_rulebook_v36_governed_repairs.sql)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Supported reviewed DWDE v3 behavior remains reproducible.
- [ ] An unsupported change to wording, strength, status, or executable policy content cannot be marked supported/current by the static compiler.
- [ ] The OPS-003 19:00 regression fails closed instead of silently returning a supposedly current 21:30 policy.
- [ ] Draft/unsupported rules have clear readiness feedback and preserve immutable policy history.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Reuse reviewed-policy provenance and inspect existing content-pinned repair precedent.
- Treat this as a temporary DWDE adapter guard, to be replaced by structured rules in T21/T25; do not create new generic-kernel exceptions.

### Non-goals

Do not implement a prose parser or the whole generic rule authoring system.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T01, T03. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T05 prompt](prompts/T05-unsupported-dwde-policy-guard.md)

<a id="t06"></a>

## T06 — Archive-aware adoption

| Field | Value |
|---|---|
| Task ID | T06 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T02, T04 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Make active inventory consistent between solver preparation and database adoption.

### Why now

The solver excludes archived sessions but adoption counts all studio sessions.

### Expected files/subsystems

- [lib/server-studio-state.ts](../lib/server-studio-state.ts)
- [supabase/migrations/20260904032500_governed_solver_candidate_adoption.sql](../supabase/migrations/20260904032500_governed_solver_candidate_adoption.sql)
- [supabase/migrations/20260905034428_planning_inventory_archive_v40.sql](../supabase/migrations/20260905034428_planning_inventory_archive_v40.sql)
- [supabase/migrations/20260905034442_planning_inventory_archive_guards_v40.sql](../supabase/migrations/20260905034442_planning_inventory_archive_guards_v40.sql)
- [tests/planning-inventory-lifecycle.test.ts](../tests/planning-inventory-lifecycle.test.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Every active session is required exactly once; archived sessions are excluded from current candidate completeness.
- [ ] Archived teachers/rooms/classes cannot be introduced into a new active candidate.
- [ ] Archive → confirm → solve → adopt and restore → reconfirm execute successfully in the disposable database.
- [ ] Historical versions still resolve archived identities; adjacent current-state count/query defects are fixed or explicitly assigned to T11/T12.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Define active session inventory including parent-class state.
- Use a forward migration, retain historical records, and inspect lock/archive interactions.

### Non-goals

Do not delete archived records, rewrite historical schedules, or broaden into generic retention policies.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T02, T04. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T06 prompt](prompts/T06-archive-aware-adoption.md)

<a id="t07"></a>

## T07 — Coherent solver snapshots

| Field | Value |
|---|---|
| Task ID | T07 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T02, T03, T05, T06 |
| Size | M |
| Risk | High |
| Reversible? | Yes |

### Objective

Build solver requests from coherent immutable planning and policy context.

### Why now

Independent reads of mutable entities and version pointers can mix facts from different moments.

### Expected files/subsystems

- [lib/server-studio-state.ts](../lib/server-studio-state.ts)
- [lib/solver-problem.ts](../lib/solver-problem.ts)
- [lib/planning-dataset.ts](../lib/planning-dataset.ts)
- [lib/constraint-model-version.ts](../lib/constraint-model-version.ts)
- [tests/solver-problem-contract.test.ts](../tests/solver-problem-contract.test.ts)
- [app/api/solver/feasibility/route.ts](../app/api/solver/feasibility/route.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Scheduling facts come from the pinned immutable planning snapshot, with compatible historical schema handling.
- [ ] Rulebook/model/current schedule and lock references belong to a coherent context; pointer changes cause retry or rejection.
- [ ] Concurrent planning/policy changes cannot submit a mixed-version request.
- [ ] The request excludes unrelated tenant data and unnecessary historical assignments.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Prefer snapshot reconstruction plus coherent pointer reads over a new event store.
- Specify snapshot/hash checks and what is allowed to change during a long solve.

### Non-goals

Do not add caching, queues, or event sourcing merely to solve consistency.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T02, T03, T05, T06. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T07 prompt](prompts/T07-coherent-solver-snapshots.md)

<a id="t08"></a>

## T08 — Candidate stale-schedule binding

| Field | Value |
|---|---|
| Task ID | T08 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T07 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Bind reviewed candidates to the base schedule and lock state.

### Why now

Adoption currently uses the schedule freshly loaded at adoption rather than the schedule the manager reviewed.

### Expected files/subsystems

- [lib/solver-problem.ts](../lib/solver-problem.ts)
- [lib/solver-gateway.ts](../lib/solver-gateway.ts)
- [app/api/solver/adopt/route.ts](../app/api/solver/adopt/route.ts)
- [app/api/solver/feasibility/route.ts](../app/api/solver/feasibility/route.ts)
- [components/solver-feasibility-card.tsx](../components/solver-feasibility-card.tsx)
- [tests/solver-gateway.test.ts](../tests/solver-gateway.test.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Candidate context includes base ScheduleVersion and unambiguous lock identity alongside studio, Rulebook, planning, and compiler/model context.
- [ ] An intervening schedule edit or lock change rejects stale adoption even when policy/planning versions are unchanged.
- [ ] The UI preserves the reviewed context and explains the need to regenerate/re-review.
- [ ] Transactional expected-version checks use submitted reviewed context, not substituted fresh values.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Test concurrent editors and repeated/double adoption.
- Version the wire contract compatibly and reject missing required context.

### Non-goals

Do not implement scenario merging or automatic conflict resolution.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T07. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T08 prompt](prompts/T08-candidate-stale-schedule-binding.md)

<a id="t09"></a>

## T09 — Session-specific solver locks

| Field | Value |
|---|---|
| Task ID | T09 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T07, T08 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Lock exact weekly sessions independently of class display names.

### Why now

Multi-session locks are explicitly unsupported and assignment/session lock representations can diverge.

### Expected files/subsystems

- [lib/solver-problem.ts](../lib/solver-problem.ts)
- [lib/solver-gateway.ts](../lib/solver-gateway.ts)
- [solver/dwde_solver/service.py](../solver/dwde_solver/service.py)
- [solver/dwde_solver/feasibility.py](../solver/dwde_solver/feasibility.py)
- [solver/tests/test_service.py](../solver/tests/test_service.py)
- [solver/tests/test_feasibility.py](../solver/tests/test_feasibility.py)
- [tests/solver-problem-contract.test.ts](../tests/solver-problem-contract.test.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] One selected session of a multi-session activity preserves day/start/teacher/room while other meetings remain movable.
- [ ] Runtime locks bind stable session IDs and preserve canonical duration.
- [ ] Assignment/session lock precedence is explicit; locked placements cannot be lost at preparation, solve, validation, or adoption.
- [ ] Missing, stale, conflicting, and impossible locks fail with deterministic explanations.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
Push-Location solver
python -m pytest -q
Pop-Location
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Apply placements directly to session variables; preserve policy-fixed assignment behavior separately.
- Use shared serialized fixtures for lock semantics on both runtimes.

### Non-goals

Do not redesign all sequencing or introduce a general locking service.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T07, T08. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T09 prompt](prompts/T09-session-specific-locks.md)

<a id="t10"></a>

## T10 — Manual MOVE through authoritative IR

| Field | Value |
|---|---|
| Task ID | T10 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T03, T04, T05, T06, T07, T08, T09 |
| Size | M |
| Risk | High |
| Reversible? | Yes before final cutover |

### Objective

Route manual MOVE through server-side canonical candidate construction and IR validation.

### Why now

Desktop/mobile moves currently commit under weaker legacy semantics than solver adoption.

### Expected files/subsystems

- [components/workspace-provider.tsx](../components/workspace-provider.tsx)
- [components/schedule/schedule-view.tsx](../components/schedule/schedule-view.tsx)
- [components/schedule/mobile-schedule-view.tsx](../components/schedule/mobile-schedule-view.tsx)
- [lib/schedule-command-candidate.ts](../lib/schedule-command-candidate.ts)
- [lib/constraint-gate-equivalence.ts](../lib/constraint-gate-equivalence.ts)
- [lib/constraint-engine-v2.ts](../lib/constraint-engine-v2.ts)
- [supabase/migrations/20260902122425_schedule_commands_v25.sql](../supabase/migrations/20260902122425_schedule_commands_v25.sql)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Server authenticates and authorizes the explicit workspace, reconstructs pinned context, derives duration, and evaluates IR before MOVE commits.
- [ ] An IR-only illegal move is rejected without a new canonical version.
- [ ] Valid desktop/mobile moves persist with version checks and audit evidence.
- [ ] Draft completeness and repair behavior are explicit; moving within a partial schedule remains possible without a false publishable claim.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Add one contained command route and restricted transaction boundary; reuse adoption infrastructure where correct.
- For this first cutover, reject wrong selected tenants rather than silently choosing first membership; full multi-tenant provisioning remains T22/T23.
- Record remaining bypasses for T13 and keep interim release blocked.

### Non-goals

Do not migrate unrelated commands or delete legacy authority before T11–T13.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T03, T04, T05, T06, T07, T08, T09. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T10 prompt](prompts/T10-manual-move-authoritative-ir.md)

<a id="t11"></a>

## T11 — ASSIGN/UNASSIGN canonical authority

| Field | Value |
|---|---|
| Task ID | T11 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T10 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes before final cutover |

### Objective

Use the shared canonical authority for incremental schedule construction.

### Why now

Partial editing must remain usable while enforcing the same placement semantics as generation.

### Expected files/subsystems

- [components/workspace-provider.tsx](../components/workspace-provider.tsx)
- [components/schedule/schedule-builder-panel.tsx](../components/schedule/schedule-builder-panel.tsx)
- [lib/schedule-command-candidate.ts](../lib/schedule-command-candidate.ts)
- [lib/constraint-engine-v2.ts](../lib/constraint-engine-v2.ts)
- [supabase/migrations/20260902122425_schedule_commands_v25.sql](../supabase/migrations/20260902122425_schedule_commands_v25.sql)
- [tests/schedule-command-candidate.test.ts](../tests/schedule-command-candidate.test.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] ASSIGN/UNASSIGN use the server candidate/validation/transaction boundary established by T10.
- [ ] Unknown or duplicate sessions, archived targets, and lock violations reject atomically.
- [ ] Partial schedules can be built and remain visibly incomplete; final completeness is evaluated separately.
- [ ] No new placement violation can be hidden by removing another assignment or comparing only aggregate counts.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Define missing-predecessor/fixed-session findings as completeness obligations where appropriate, not blanket blockers to incremental construction.
- Test legal incremental sequences, disallowed placements, and no-op/retry behavior.

### Non-goals

Do not introduce a drag-and-drop redesign or universal repair search.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T10. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T11 prompt](prompts/T11-assign-unassign-authority.md)

<a id="t12"></a>

## T12 — Rebase/undo canonical authority

| Field | Value |
|---|---|
| Task ID | T12 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T10, T11 |
| Size | M |
| Risk | High |
| Reversible? | Yes with retained history |

### Objective

Use the shared authority for recovery and revalidation.

### Why now

Legacy recovery can reintroduce assignments invalid under the complete current model.

### Expected files/subsystems

- [components/workspace-provider.tsx](../components/workspace-provider.tsx)
- [components/versions-view.tsx](../components/versions-view.tsx)
- [lib/schedule-command-candidate.ts](../lib/schedule-command-candidate.ts)
- [supabase/migrations/20260902122425_schedule_commands_v25.sql](../supabase/migrations/20260902122425_schedule_commands_v25.sql)
- [tests/schedule-commands-v25.test.ts](../tests/schedule-commands-v25.test.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Undo, rebase, and revalidation use coherent context and the same deterministic scheduling semantics.
- [ ] Recovery creates a new version and never rewrites historical assignments or facts.
- [ ] Incompatible current-policy restores fail clearly; historical inspection remains possible.
- [ ] Archive/duration changes and stale version tokens cannot corrupt recovered state.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Distinguish inspect old version from adopt old assignments under current policy.
- Preserve compatible one-step undo; generalized history branching is not needed.

### Non-goals

Do not implement scenario merge, arbitrary rollback of production data, or event sourcing.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T10, T11. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T12 prompt](prompts/T12-rebase-undo-authority.md)

<a id="t13"></a>

## T13 — Close legacy write bypasses

| Field | Value |
|---|---|
| Task ID | T13 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T10, T11, T12 |
| Size | S |
| Risk | High |
| Reversible? | Forward repair; no insecure rollback |

### Objective

Make the shared server validation path unavoidable for canonical schedule writes.

### Why now

Leaving authenticated legacy RPCs callable defeats a UI-only migration.

### Expected files/subsystems

- [supabase/migrations/20260902122425_schedule_commands_v25.sql](../supabase/migrations/20260902122425_schedule_commands_v25.sql)
- [supabase/migrations/20260904032500_governed_solver_candidate_adoption.sql](../supabase/migrations/20260904032500_governed_solver_candidate_adoption.sql)
- [supabase/migrations/20260902163046_constraint_model_publication_v30.sql](../supabase/migrations/20260902163046_constraint_model_publication_v30.sql)
- [lib/supabase.ts](../lib/supabase.ts)
- [app/api/solver/adopt/route.ts](../app/api/solver/adopt/route.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] All superseded canonical scheduling write entry points are revoked or delegate safely; authenticated callers cannot bypass IR.
- [ ] Privileged transactions recheck the actor's current role for the explicit studio and version context.
- [ ] Constraint publication is server-derived or equivalently protected against arbitrary client artifacts.
- [ ] Executed privilege enumeration and direct-RPC tests demonstrate no legacy bypass; retained historical readers are documented.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Inventory grants/functions before removal; preserve minimum SQL structural safeguards.
- Ship grant changes only after every active client path is migrated.

### Non-goals

Do not delete historical migrations or roll back to a weaker authority if problems occur; keep read-only mode and forward-fix.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T10, T11, T12. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T13 prompt](prompts/T13-close-legacy-write-bypasses.md)

<a id="t14"></a>

## T14 — Representative full DWDE acceptance fixture/solve

| Field | Value |
|---|---|
| Task ID | T14 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T05, T06, T07, T08, T09, T10, T11, T12, T13 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Prove the full real scheduling workload and establish shared parity fixtures.

### Why now

Small passing fixtures do not establish complete planning data or operational solve performance.

### Expected files/subsystems

- [tests/golden-schedule-fixtures.test.ts](../tests/golden-schedule-fixtures.test.ts)
- [tests/constraint-engine.test.ts](../tests/constraint-engine.test.ts)
- [tests/constraint-engine-coverage.test.ts](../tests/constraint-engine-coverage.test.ts)
- [tests/solver-problem-contract.test.ts](../tests/solver-problem-contract.test.ts)
- [solver/tests/test_feasibility.py](../solver/tests/test_feasibility.py)
- [lib/schedule-readiness.ts](../lib/schedule-readiness.ts)
- [lib/delegated-solver-preflight.ts](../lib/delegated-solver-preflight.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] A manager-reviewed complete DWDE snapshot records people/classes/sessions/rosters/qualifications/availability and known omissions explicitly.
- [ ] A representative full solve covers every active session; independent IR validation, adoption, edit, and recovery pass in staging.
- [ ] Shared serialized fixtures run against TypeScript and Python, including feasible/infeasible, qualifications, durations, locks, and delegated preconditions.
- [ ] Runtime/solver default-deny and name-normalization discrepancies are fixed; unsupported semantics fail closed.
- [ ] Benchmark records hardware, pinned versions, request hash, wall time, memory/concurrency envelope, and manager-agreed operational threshold.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
Push-Location solver
python -m pytest -q
Pop-Location
npm run test:parity
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Introduce npm run test:parity as the cross-runtime fixture command.
- Use private artifacts for identifiable studio data, deidentified fixtures in Git, and no live production writes.
- Missing complete data is a real external blocker; synthetic facts cannot be represented as manager-approved DWDE completeness.

### Non-goals

Do not call toy fixtures full DWDE acceptance or expand objectives before HARD correctness.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T05, T06, T07, T08, T09, T10, T11, T12, T13. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T14 prompt](prompts/T14-dwde-acceptance-fixture.md)

<a id="t15"></a>

## T15 — Bounded and understandable solve failures

| Field | Value |
|---|---|
| Task ID | T15 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T14 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Bound total solving/diagnostics and explain failure without false guarantees.

### Why now

A diagnostic second solve can exceed gateway timeout; blocker IDs are not rendered usefully.

### Expected files/subsystems

- [solver/dwde_solver/feasibility.py](../solver/dwde_solver/feasibility.py)
- [solver/dwde_solver/service.py](../solver/dwde_solver/service.py)
- [app/api/solver/feasibility/route.ts](../app/api/solver/feasibility/route.ts)
- [components/solver-feasibility-card.tsx](../components/solver-feasibility-card.tsx)
- [solver/tests/test_service.py](../solver/tests/test_service.py)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] One total deadline bounds preparation/search/diagnostics and fits the deployment timeout budget.
- [ ] FEASIBLE, INFEASIBLE, UNKNOWN, unsupported, precondition, malformed-service, and transport failures are distinct.
- [ ] Existing diagnostic constraint IDs are mapped to readable policy/entity evidence; empty cores do not imply no conflict.
- [ ] Fixed-anchor cores are labeled sufficient/partial, never guaranteed globally minimal; repair proposals never mutate canonical state.
- [ ] Placement explanations and simple empty-domain checks point to actionable facts/rules.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
Push-Location solver
python -m pytest -q
Pop-Location
npm run test:parity
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Validate service context for non-success replies as well as candidates.
- Keep deterministic explanation provenance; measure model build time as well as solver time.

### Non-goals

Do not build exact minimal conflicts, minimum-cost repairs, or an academic diagnostic framework.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T14. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T15 prompt](prompts/T15-bounded-solve-diagnostics.md)

<a id="t16"></a>

## T16 — Manager workflow/export/mobile verification

| Field | Value |
|---|---|
| Task ID | T16 |
| Status | NOT_STARTED |
| Milestone | A |
| Priority | P0 |
| Dependencies | T14, T15 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Complete the smallest DWDE workflow a manager can use independently.

### Why now

Generation without practical review, recovery, printable output, and deployed verification is not operational readiness.

### Expected files/subsystems

- [components/schedule/schedule-view.tsx](../components/schedule/schedule-view.tsx)
- [components/schedule/mobile-schedule-view.tsx](../components/schedule/mobile-schedule-view.tsx)
- [components/solver-feasibility-card.tsx](../components/solver-feasibility-card.tsx)
- [components/settings-view.tsx](../components/settings-view.tsx)
- [components/versions-view.tsx](../components/versions-view.tsx)
- [lib/supabase.ts](../lib/supabase.ts)
- [.env.example](../.env.example)
- [vercel.json](../vercel.json)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Every step and evidence requirement in DWDE_RELEASE_PLAN.md passes with Cami or a named delegated manager.
- [ ] Schedule export/print includes version context and all active sessions; mobile view and essential form-based edits work.
- [ ] Authenticated owner/editor/viewer staging checks and environment/solver credentials pass; production fallback defaults are removed safely.
- [ ] A documented disposable restore/recovery drill succeeds; live deployment/migration status is recorded by an authorized release operator.
- [ ] AI is either aligned enough for current factual explanation or misleading mutation/legacy guidance is hidden before launch.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
Push-Location solver
python -m pytest -q
Pop-Location
npm run test:parity
npm run test:e2e
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Introduce npm run test:e2e for repeatable authenticated staging/local smoke tests, using test users only.
- Put hashes/compiler details in advanced views; distinguish user acceptance from HTTP 200 checks.
- Record open P1 preference needs; promote T17–T19 if first-feasible output is operationally unusable.

### Non-goals

Do not claim production certification without release evidence or silently implement all AI features.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T14, T15. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T16 prompt](prompts/T16-manager-workflow-export.md)

<a id="t17"></a>

## T17 — Preference scoring

| Field | Value |
|---|---|
| Task ID | T17 |
| Status | NOT_STARTED |
| Milestone | C |
| Priority | P1 |
| Dependencies | T14 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Define a small set of deterministic, manager-understandable preference scores.

### Why now

The current OPT priority spine is metadata rather than an executable objective.

### Expected files/subsystems

- [lib/constraint-ir.ts](../lib/constraint-ir.ts)
- [lib/constraint-compiler-v3.ts](../lib/constraint-compiler-v3.ts)
- [lib/domain.ts](../lib/domain.ts)
- [lib/solver-problem.ts](../lib/solver-problem.ts)
- [tests/constraint-compiler.test.ts](../tests/constraint-compiler.test.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Initial preference families and their units are explicitly selected from manager needs.
- [ ] HARD remains feasibility; VERY_STRONG > MODERATE > LIGHT > BASELINE semantics are explicit.
- [ ] Known candidate pairs rank as intended and rescore deterministically with readable components.
- [ ] DWDE OPT codes map through tenant policy data/adapter, not a new reusable Rule-ID dispatch.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:parity
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Start with counts, days, or gap minutes; bound penalties and record policy priority decisions.
- Introduce shared serialized scoring fixtures and annotate unsupported preferences clearly.

### Non-goals

Do not invent arbitrary giant weights, implement every soft rule, or claim universal utility scores.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T14. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T17 prompt](prompts/T17-preference-scoring.md)

<a id="t18"></a>

## T18 — Soft optimization

| Field | Value |
|---|---|
| Task ID | T18 |
| Status | NOT_STARTED |
| Milestone | C |
| Priority | P1 |
| Dependencies | T17, T15 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Use CP-SAT to improve schedules while preserving deterministic HARD correctness.

### Why now

Good schedules are necessary for repeatable commercial use after trustworthy feasibility exists.

### Expected files/subsystems

- [solver/dwde_solver/feasibility.py](../solver/dwde_solver/feasibility.py)
- [solver/dwde_solver/service.py](../solver/dwde_solver/service.py)
- [lib/solver-gateway.ts](../lib/solver-gateway.ts)
- [solver/tests/test_feasibility.py](../solver/tests/test_feasibility.py)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Initial penalties translate consistently to CP-SAT and independent scoring.
- [ ] Hierarchical optimization protects higher-tier achieved results; proven optimality is distinguished from a time-limited incumbent.
- [ ] HARD violations remain zero and locks/version context remain intact.
- [ ] Reported score, bound/status, and per-tier units agree with deterministic rescoring under a bounded total request budget.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
Push-Location solver
python -m pytest -q
Pop-Location
npm run test:parity
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Prefer sequential tier optimization; if a tier is not proven optimal, report that limitation precisely.
- Retain a feasibility-only mode and consistent service contract.

### Non-goals

Do not replace CP-SAT or introduce a separate optimization service.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T17, T15. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T18 prompt](prompts/T18-soft-optimization.md)

<a id="t19"></a>

## T19 — Candidate comparison/persistence

| Field | Value |
|---|---|
| Task ID | T19 |
| Status | NOT_STARTED |
| Milestone | C |
| Priority | P1 |
| Dependencies | T18, T08, T16 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Persist and compare a small number of useful schedule alternatives.

### Why now

Current results are transient and repeatable same-seed solves do not provide meaningful choice.

### Expected files/subsystems

- [components/solver-feasibility-card.tsx](../components/solver-feasibility-card.tsx)
- [components/schedule/schedule-view.tsx](../components/schedule/schedule-view.tsx)
- [app/api/solver/adopt/route.ts](../app/api/solver/adopt/route.ts)
- [lib/solver-gateway.ts](../lib/solver-gateway.ts)
- [solver/dwde_solver/feasibility.py](../solver/dwde_solver/feasibility.py)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Two or three materially distinct candidates can be generated within supported budgets, with explicit diversity criteria.
- [ ] Candidates survive refresh and retain immutable policy/planning/base-schedule/lock context.
- [ ] Candidate-versus-current and candidate-versus-candidate differences show understandable preference tradeoffs.
- [ ] All alternatives independently validate/rescore and adoption rejects stale context.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
Push-Location solver
python -m pytest -q
Pop-Location
npm run test:parity
npm run test:e2e
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Add minimal candidate persistence via forward migration; keep canonical schedules separate.
- Protect candidate rows with tenant authorization and avoid storing unnecessary personal data.

### Non-goals

Do not implement unlimited enumeration, generalized scenarios, or branch merge.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T18, T08, T16. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T19 prompt](prompts/T19-candidate-comparison-persistence.md)

<a id="t20"></a>

## T20 — Typed ID targets/parameters

| Field | Value |
|---|---|
| Task ID | T20 |
| Status | NOT_STARTED |
| Milestone | B |
| Priority | P1 |
| Dependencies | T14 |
| Size | L |
| Risk | High |
| Reversible? | Additive with compatibility |

### Objective

Make executable rule targets and parameter contracts stable and tenant-neutral.

### Why now

Names, Unicode normalization, and broad JSON parameters currently carry identity and ambiguous semantics.

### Expected files/subsystems

- [lib/constraint-ir.ts](../lib/constraint-ir.ts)
- [lib/constraint-data-binding.ts](../lib/constraint-data-binding.ts)
- [lib/constraint-engine.ts](../lib/constraint-engine.ts)
- [lib/constraint-engine-v2.ts](../lib/constraint-engine-v2.ts)
- [lib/delegated-solver-preflight.ts](../lib/delegated-solver-preflight.ts)
- [solver/dwde_solver/feasibility.py](../solver/dwde_solver/feasibility.py)
- [lib/domain.ts](../lib/domain.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Typed discriminated parameters cover all supported kinds with explicit unsupported-parameter rejection.
- [ ] teacherIds/studentIds/roomIds/classIds/cohortIds/sessionIds or equivalent typed targets bind uniquely within the pinned tenant dataset.
- [ ] Display-name renames and Unicode/punctuation differences cannot change legality or score.
- [ ] Existing DWDE artifacts remain reproducible through versioned compatibility; missing/archived IDs fail explicitly.
- [ ] Rule kind, selectors, exceptions, runtime, solver, and explanations share serialized parity cases.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
Push-Location solver
python -m pytest -q
Pop-Location
npm run test:parity
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Split as T20a target/binding contract, T20b placement/resource families, T20c sequencing/progression/exception families; parent DONE only after all pass.
- Resolve names during reviewed import; keep policy definition independent of mutable dataset contents.
- Use explicit taxonomy codes/relationships; no substring-based progression.

### Non-goals

Do not build an enormous DSL, rename every domain table, or add a policy plugin system.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T14. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T20 prompt](prompts/T20-typed-id-targets.md)

<a id="t21"></a>

## T21 — Convert DWDE policy into tenant records

| Field | Value |
|---|---|
| Task ID | T21 |
| Status | NOT_STARTED |
| Milestone | B |
| Priority | P1 |
| Dependencies | T20 |
| Size | L |
| Risk | High |
| Reversible? | Preserve old artifacts; staged migration |

### Objective

Retain DWDE's behavior as tenant policy while removing source-code dispatch.

### Why now

Compiler, readiness, intake, and SQL contain named people/classes, 178-rule assumptions, and curriculum special cases.

### Expected files/subsystems

- [lib/constraint-compiler.ts](../lib/constraint-compiler.ts)
- [lib/constraint-compiler-v3.ts](../lib/constraint-compiler-v3.ts)
- [lib/rule-execution-registry.ts](../lib/rule-execution-registry.ts)
- [lib/schedule-readiness.ts](../lib/schedule-readiness.ts)
- [lib/planning-class-structure.ts](../lib/planning-class-structure.ts)
- [lib/planning-roster-repair.ts](../lib/planning-roster-repair.ts)
- [lib/required-class-intake.ts](../lib/required-class-intake.ts)
- [supabase/migrations/20260904190328_rulebook_v36_governed_repairs.sql](../supabase/migrations/20260904190328_rulebook_v36_governed_repairs.sql)
- [supabase/migrations/20260904215241_shared_rulebook_roster_compiler_v38.sql](../supabase/migrations/20260904215241_shared_rulebook_roster_compiler_v38.sql)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] DWDE people, rules, exceptions, curriculum/enrollment requirements, and historical versions remain intact.
- [ ] Generic compilation and readiness no longer require DWDE Rule IDs, names, fixed count 178, or specific levels/subjects.
- [ ] New tenant records reproduce the golden DWDE semantics and renamed fixture invariance.
- [ ] DWDE intake triggers are tenant-scoped during transition; unrelated classes cannot activate DWDE repair policy.
- [ ] Every actionable leakage item is resolved or explicitly assigned with evidence.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
Push-Location solver
python -m pytest -q
Pop-Location
npm run test:parity
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Split T21a compiler/registry policy records and T21b readiness/intake/repair requirements.
- Use ordinary tenant records, forward data migrations, and a controlled DWDE adapter; retain historical migration text.

### Non-goals

Do not remove DWDE, reseed production destructively, or introduce policy-pack inheritance infrastructure.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T20. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T21 prompt](prompts/T21-dwde-tenant-policy.md)

<a id="t22"></a>

## T22 — Tenant-explicit database commands

| Field | Value |
|---|---|
| Task ID | T22 |
| Status | NOT_STARTED |
| Milestone | B |
| Priority | P1 |
| Dependencies | T02, T13, T16 |
| Size | L |
| Risk | High |
| Reversible? | Staged compatibility; privileges forward-only |

### Objective

Authorize and mutate the explicitly selected tenant in every command.

### Why now

First-membership actor selection risks wrong-workspace writes for users with multiple memberships.

### Expected files/subsystems

- [supabase/production-ledger/20260831123403_v2_1_governed_infrastructure.sql](../supabase/production-ledger/20260831123403_v2_1_governed_infrastructure.sql)
- [supabase/production-ledger/20260831123611_v2_1_entity_membership_mutations.sql](../supabase/production-ledger/20260831123611_v2_1_entity_membership_mutations.sql)
- [components/workspace-provider.tsx](../components/workspace-provider.tsx)
- [app/api/solver/adopt/route.ts](../app/api/solver/adopt/route.ts)
- [app/api/copilot/route.ts](../app/api/copilot/route.ts)
- [supabase/functions/user-openrouter/index.ts](../supabase/functions/user-openrouter/index.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Every active public command accepts/derives an explicit request tenant and authorizes that exact membership inside its transaction.
- [ ] Two memberships with different roles never route a write to the first/stronger membership.
- [ ] Cross-tenant IDs/references, candidate access, policy/planning/version/audit reads and writes reject.
- [ ] New identifiers are globally opaque; tenant-local Rule display codes can repeat without identity collision.
- [ ] Old ambiguous RPCs are revoked or safe wrappers; role revocation races and last-owner behavior are tested.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
npm run test:e2e
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Split T22a scheduling/planning, T22b policy/artifacts, T22c membership/AI and privilege audit.
- Add same-studio checks and composite relational constraints where practical; preserve existing IDs.

### Non-goals

Do not rebuild authentication or infer authorization from user-editable metadata.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T02, T13, T16. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T22 prompt](prompts/T22-tenant-explicit-commands.md)

<a id="t23"></a>

## T23 — Tenant initialization/selection

| Field | Value |
|---|---|
| Task ID | T23 |
| Status | NOT_STARTED |
| Milestone | C |
| Priority | P1 |
| Dependencies | T22 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Create and select independent organizations through a standard supported flow.

### Why now

Storage contains studios but the application and routes hard-code DWDE.

### Expected files/subsystems

- [components/workspace-provider.tsx](../components/workspace-provider.tsx)
- [components/app-shell.tsx](../components/app-shell.tsx)
- [components/planning-archive-panel.tsx](../components/planning-archive-panel.tsx)
- [app/api/solver/feasibility/route.ts](../app/api/solver/feasibility/route.ts)
- [app/api/solver/adopt/route.ts](../app/api/solver/adopt/route.ts)
- [app/api/copilot/route.ts](../app/api/copilot/route.ts)
- [supabase/bootstrap/2026-08-31-production-schema-baseline.sql](../supabase/bootstrap/2026-08-31-production-schema-baseline.sql)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] A new organization initializes required empty/versioned state without copying DWDE operational records.
- [ ] Membership selection determines all workspace reads/writes and survives navigation safely.
- [ ] Users with no membership have a clear provisioning path; users with multiple memberships can select explicitly.
- [ ] Standard operator provisioning is documented and retry-safe; DWDE remains prepopulated.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
npm run test:e2e
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Manual operator provisioning is acceptable during pilot, bespoke SQL per customer is not.
- Keep initialization atomic and guard empty-tenant solving until setup completes.

### Non-goals

Do not build advanced self-service billing, organization hierarchy, or tenant cloning.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T22. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T23 prompt](prompts/T23-tenant-initialization-selection.md)

<a id="t24"></a>

## T24 — Remove DWDE operational UI assumptions

| Field | Value |
|---|---|
| Task ID | T24 |
| Status | NOT_STARTED |
| Milestone | C |
| Priority | P1 |
| Dependencies | T20, T21, T23 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Display and configure the actual tenant's operating structure.

### Why now

Weekly view truncates to three rooms; hours, days, and start defaults encode DWDE.

### Expected files/subsystems

- [components/schedule/schedule-view.tsx](../components/schedule/schedule-view.tsx)
- [components/schedule/mobile-schedule-view.tsx](../components/schedule/mobile-schedule-view.tsx)
- [lib/schedule-builder.ts](../lib/schedule-builder.ts)
- [lib/domain.ts](../lib/domain.ts)
- [components/settings-view.tsx](../components/settings-view.tsx)
- [components/app-shell.tsx](../components/app-shell.tsx)
- [app/layout.tsx](../app/layout.tsx)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] All configured rooms render; no slice(0,3) data loss.
- [ ] Morning hours and configured operating windows render and edit consistently on desktop/mobile.
- [ ] Supported days/grid are explicit and consistent across UI, commands, IR, Python, and SQL; unsupported inputs reject instead of truncate.
- [ ] Tenant name/terminology replaces misleading DWDE presentation defaults while DWDE retains its own branding/data.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
Push-Location solver
python -m pytest -q
Pop-Location
npm run test:parity
npm run test:e2e
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Do not add Sunday/finer grids blindly: declare pilot scope, then implement if acceptance demand requires it.
- Separate display horizon from legal operating windows.

### Non-goals

Do not redesign the app or add arbitrary resource bundles/multi-instructor scheduling.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T20, T21, T23. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T24 prompt](prompts/T24-tenant-operational-ui.md)

<a id="t25"></a>

## T25 — Generic structured rule authoring

| Field | Value |
|---|---|
| Task ID | T25 |
| Status | NOT_STARTED |
| Milestone | C |
| Priority | P1 |
| Dependencies | T20, T21, T23 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Allow unrelated studios to express supported policy without source edits.

### Why now

Current human wording edits cannot safely author executable rule parameters.

### Expected files/subsystems

- [components/rulebook/rulebook-view.tsx](../components/rulebook/rulebook-view.tsx)
- [lib/domain.ts](../lib/domain.ts)
- [lib/constraint-ir.ts](../lib/constraint-ir.ts)
- [lib/constraint-compiler-v3.ts](../lib/constraint-compiler-v3.ts)
- [lib/copilot-contract.ts](../lib/copilot-contract.ts)
- [supabase/migrations/20260831160600_v2_2_rule_mutations.sql](../supabase/migrations/20260831160600_v2_2_rule_mutations.sql)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Forms support agreed pilot qualification, availability, room, operating-hours, sequencing, lock-related policy, and preference families.
- [ ] Typed targets/exceptions/strengths preview deterministic meaning and provenance before approval.
- [ ] Unsupported HARD semantics block readiness; edits version policy and invalidate stale candidates appropriately.
- [ ] Studio #2 policies can be authored with no compiler/solver/application changes.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
npm run test:parity
npm run test:e2e
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Implement one template family per bounded session under T25; record child traceability if necessary.
- Human wording remains readable alongside the structured authority.

### Non-goals

Do not implement free-form executable prose, a general DSL, or AI approval authority.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T20, T21, T23. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T25 prompt](prompts/T25-structured-rule-authoring.md)

<a id="t26"></a>

## T26 — CSV intake

| Field | Value |
|---|---|
| Task ID | T26 |
| Status | NOT_STARTED |
| Milestone | C |
| Priority | P1 |
| Dependencies | T23, T24, T25 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes via version/archive |

### Objective

Provide reviewed, repeatable planning-data imports.

### Why now

Manual bespoke loading does not establish commercial onboarding.

### Expected files/subsystems

- [lib/import-validator.ts](../lib/import-validator.ts)
- [components/people-view.tsx](../components/people-view.tsx)
- [components/classes-view.tsx](../components/classes-view.tsx)
- [lib/planning-inventory-client.ts](../lib/planning-inventory-client.ts)
- [lib/reviewed-rulebook.ts](../lib/reviewed-rulebook.ts)
- [tests/import-validator.test.ts](../tests/import-validator.test.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] CSV preview validates required fields, durations, supported day/grid, duplicate identity, qualification and roster references, and tenant ownership.
- [ ] Name resolution/ambiguities are reviewed at intake and committed as stable IDs.
- [ ] Atomic commit rejects the entire invalid batch; retries do not duplicate records.
- [ ] Import provenance and counts are recorded; planning changes invalidate confirmation/candidates; no production import during tests.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
npm run test:e2e
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Use CSV before management-platform integration; preserve DWDE's reviewed importer as an explicitly tenant-specific adapter.
- Define external row keys separately from canonical IDs.

### Non-goals

Do not build deep integrations or accept unvalidated direct table writes.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T23, T24, T25. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T26 prompt](prompts/T26-csv-intake.md)

<a id="t27"></a>

## T27 — Studio #2 acceptance

| Field | Value |
|---|---|
| Task ID | T27 |
| Status | NOT_STARTED |
| Milestone | C |
| Priority | P1 |
| Dependencies | T19, T21, T22, T23, T24, T25, T26 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes |

### Objective

Demonstrate unrelated onboarding without bespoke code.

### Why now

This is the commercialization gate rather than inferred genericity from types.

### Expected files/subsystems

- [plans/STUDIO_2_ACCEPTANCE.md](../plans/STUDIO_2_ACCEPTANCE.md)
- [tests/golden-schedule-fixtures.test.ts](../tests/golden-schedule-fixtures.test.ts)
- [tests/solver-problem-contract.test.ts](../tests/solver-problem-contract.test.ts)
- [solver/tests/test_feasibility.py](../solver/tests/test_feasibility.py)
- [components/workspace-provider.tsx](../components/workspace-provider.tsx)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] Every criterion and evidence requirement in STUDIO_2_ACCEPTANCE.md passes.
- [ ] At least 4 instructors/4 rooms/30 participants/12 activities/20 weekly sessions use non-DWDE policy and taxonomy.
- [ ] Onboarding, solve, rescore, compare, adopt, edit, archive/restore, export, and selected-tenant isolation require zero tenant-specific code.
- [ ] Rename invariance and known infeasible/UNKNOWN cases pass; unverified criteria remain explicitly open.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
Push-Location solver
python -m pytest -q
Pop-Location
npm run test:parity
npm run test:e2e
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Freeze implementation SHA before onboarding; any bespoke code resets this acceptance run.
- Use standard provisioning/imports; operator assistance can clarify input but cannot implement a customer-specific compiler.

### Non-goals

Do not call a renamed DWDE dataset Studio #2 or waive isolation criteria.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T19, T21, T22, T23, T24, T25, T26. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T27 prompt](prompts/T27-studio-2-acceptance.md)

<a id="t28"></a>

## T28 — AI canonical-context alignment

| Field | Value |
|---|---|
| Task ID | T28 |
| Status | NOT_STARTED |
| Milestone | E |
| Priority | P2 |
| Dependencies | T25, T22, T27 |
| Size | M |
| Risk | Medium |
| Reversible? | Yes; optional feature can remain hidden |

### Objective

Align optional AI assistance with the same coherent tenant/version context and reviewed templates.

### Why now

Copilot currently describes legacy enforcement mappings and omits planning/model freshness.

### Expected files/subsystems

- [app/api/copilot/route.ts](../app/api/copilot/route.ts)
- [lib/copilot-contract.ts](../lib/copilot-contract.ts)
- [components/copilot-panel.tsx](../components/copilot-panel.tsx)
- [supabase/functions/user-openrouter/index.ts](../supabase/functions/user-openrouter/index.ts)
- [tests/copilot-contract.test.ts](../tests/copilot-contract.test.ts)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] AI context uses selected tenant and pinned current policy/planning/model/schedule state, excluding archived facts unless explicitly historical.
- [ ] Rule proposals use supported structured templates and require human review; AI cannot mutate canonical state directly.
- [ ] Explanations cite deterministic findings; hallucinated IDs/unsupported parameters/stale proposals fail.
- [ ] Scenario requests remain proposals unless a real isolated scenario workflow exists; AI failure does not block manual scheduling.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
npm run test:e2e
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- T16 handles minimum launch-safe hiding/correction earlier; this task is fuller optional alignment.
- Test injection, stale context, viewers, cross-tenant references, provider failure, and model output allowlists.

### Non-goals

Do not infer canonical policy from model output or implement judgment learning/autonomous changes.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T25, T22, T27. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T28 prompt](prompts/T28-ai-canonical-context.md)

<a id="t29"></a>

## T29 — Paid-pilot operations

| Field | Value |
|---|---|
| Task ID | T29 |
| Status | NOT_STARTED |
| Milestone | D/E/F |
| Priority | P2 |
| Dependencies | T16, T19, T27 |
| Size | M |
| Risk | Medium |
| Reversible? | Mostly; billing changes require review |

### Objective

Support 3–5 real pilots and repeatable commercial MVP operations, then measure 10–25 customer evidence.

### Why now

Commercial success requires operational reliability and manageable onboarding/support economics.

### Expected files/subsystems

- [.github/workflows/ci.yml](../.github/workflows/ci.yml)
- [.github/workflows/solver-ci.yml](../.github/workflows/solver-ci.yml)
- [solver/Dockerfile](../solver/Dockerfile)
- [app/api/solver/feasibility/route.ts](../app/api/solver/feasibility/route.ts)
- [app/api/copilot/route.ts](../app/api/copilot/route.ts)
- [vercel.json](../vercel.json)
- [.env.example](../.env.example)
- [plans/DWDE_RELEASE_PLAN.md](../plans/DWDE_RELEASE_PLAN.md)

Paths above exist at the planning baseline. New routes, fixtures, forward migrations, or scripts must be named after inspecting the implementation; they are not claimed to exist yet.

### Acceptance criteria

- [ ] 3–5 organizations use real schedules with recorded generation/adoption success and onboarding effort.
- [ ] Tenant usage/concurrency limits, total deadlines, actionable redacted logs, support process, and recovery runbook are verified.
- [ ] Basic billing/entitlements or documented standard manual invoicing supports pilots; repeatable MVP operations are explicit.
- [ ] A 10–25 customer measurement protocol tracks paid retention, accepted schedules, support cost, bespoke engineering, and integration requests; growth itself is not falsely marked achieved.
- [ ] Data export/deletion handling, credential rotation, restore evidence, and supported workload limits have named operational owners.

### Required tests

Run the exact commands below from the repository root using the isolated test environment described in TEST_STRATEGY.md. Commands introduced by predecessor tasks must exist before execution; missing commands are a blocker, not a pass.

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run test:db
Push-Location solver
python -m pytest -q
Pop-Location
npm run test:parity
npm run test:e2e
```

Add regression tests exercising each acceptance criterion, including rejection/no-write behavior. Existing tests alone do not establish this task's completion. Database text assertions cannot substitute for executed transaction/RLS tests.

### Implementation notes

- Split operational slices under T29 if needed; external adoption and customer growth remain milestone evidence, not code-completion claims.
- AI optional; if shipped, T28 is an additional release dependency.
- Do not create automation or contact customers without separate authorization.

### Non-goals

Do not build advanced billing, broad integrations, scale infrastructure, or fabricate customer evidence.

### Completion evidence

Not yet verified. Record commit SHA, exact commands/exit codes, environment, regression cases, artifact links, manager acceptance where required, and remaining limitations. No implementation task was marked DONE during plan creation.

### Notes/blockers

Waiting for dependency acceptance: T16, T19, T27. This is normal sequencing, not a BLOCKED status.

Record discovered blockers as BLK-NNN in this section with evidence, impact, owner/action, and unblock criterion; link cross-task blockers from README.md. Record plan changes in DECISIONS.md.

### Implementation prompt

[Open T29 prompt](prompts/T29-paid-pilot-operations.md)

